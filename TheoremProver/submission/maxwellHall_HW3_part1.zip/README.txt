CS 4365 HW 3 Part I

AUTHOR: Maxwell Hall

PLATFORM: Mac OS X 10.10
LANGUAGE: Python 2.7

HOW TO RUN:
1) put main.py and KnowledgeBase.py in the same directory
2) execute the following command:
    python main.py <input file path relative to the working directory>
